from taxjar.client import Client

DEFAULT_API_URL = 'https://api.taxjar.com'
SANDBOX_API_URL = 'https://api.sandbox.taxjar.com'
API_VERSION = 'v2'
VERSION = '1.9.2'
